const express    = require("express");
const siteRoutes = express.Router();

let middlewareForHomePage =  (req, res, next) => {
  console.log("Hey, I am a middleware just for the home page!!")
  next()
}

siteRoutes.get("/", middlewareForHomePage, (req, res, next) => {
  res.render("index");
});

siteRoutes.use((req, res, next) => {
  if (req.session.currentUser) {
    res.redirect("/");
    next();
  } else {
    res.redirect("/login");
  }
});

siteRoutes.get("/home", (req, res, next) => {
  res.render("home");
});

// siteRoutes.get("/main", (req, res, next) => {
//   res.render("auth/main");
// });

// siteRoutes.get("/private", (req, res, next) => {
//   res.render("auth/private");
// });


module.exports = siteRoutes;